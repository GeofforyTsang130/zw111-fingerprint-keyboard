"""Read one complete ZW111 UART response at a time."""
import time


class FingerprintUART:
    def __init__(self, uart):
        self.uart = uart

    def _read_exact(self, length, deadline):
        result = bytearray()
        while len(result) < length and time.monotonic() < deadline:
            chunk = self.uart.read(length - len(result))
            if chunk:
                result.extend(chunk)
            else:
                time.sleep(.002)
        return result if len(result) == length else None

    def command(self, data, timeout=2.0):
        length = len(data) + 2
        payload = bytes((1, length >> 8, length & 255)) + data
        packet = b"\xef\x01\xff\xff\xff\xff" + payload + (sum(payload) & 65535).to_bytes(2, "big")
        self.uart.reset_input_buffer()
        self.uart.write(packet)
        deadline = time.monotonic() + timeout
        while time.monotonic() < deadline:
            header = self._read_exact(9, deadline)
            if header is None or header[:2] != b"\xef\x01" or header[6] != 7:
                return None
            length = int.from_bytes(header[7:9], "big")
            if not 3 <= length <= 256:
                return None
            tail = self._read_exact(length, deadline)
            if tail is None:
                return None
            reply = bytes(tail[:-2])
            if (sum(header[6:]) + sum(reply)) & 65535 != int.from_bytes(tail[-2:], "big"):
                return None
            # No-finger is a capture reply, not a feature-extraction result.
            if data[0] == 0x02 and reply == b"\x02":
                continue
            # A bare success ACK never authorizes a macro. A successful search
            # returns both the template number and the score.
            if data[0] == 0x04 and reply[0] == 0 and len(reply) != 5:
                continue
            return reply
        return None
