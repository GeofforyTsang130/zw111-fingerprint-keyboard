def _zw111_bluetooth_name():
 try:
  with open('/.zw111-ble-name','rb') as source:
   raw=source.read(25)
  name=raw.decode().strip()
  if name and len(raw)<=24 and all(ord(c)>=32 and ord(c)!=127 for c in name):
   return name
 except (OSError,UnicodeError):
  pass
 return 'zizizi'

from zw111_match_led import flash_green, LIGHT_OFF, WAIT_LIGHT
from zw111_sensor import FingerprintUART
from zw111_vibration import init_vibration_output, read_vibration_level, save_vibration_level, pulse_vibration
# ZW111 light-saving mode: touch-driven standby, BLE retained, both idle LEDs off.
import time, board, busio, usb_hid, usb_cdc, digitalio, json, alarm, supervisor, espidf
supervisor.runtime.rgb_status_brightness=0
_board_led=digitalio.DigitalInOut(board.IO48)
_board_led.switch_to_output(value=False)
match_output=init_vibration_output(digitalio,board.IO3)
vibration_setting=read_vibration_level()
def vibration_level(selected=None):
 global vibration_setting
 if selected is not None and selected!=vibration_setting:
  save_vibration_level(selected)
  vibration_setting=selected
 return vibration_setting
print('LS2 CHIP_AUTO_LIGHT firmware running')
CONNECT_TIMEOUT=25
SETTLE_SECONDS=2.0
u=busio.UART(board.IO43,board.IO44,baudrate=57600,timeout=0)
cmd=FingerprintUART(u).command
touch=digitalio.DigitalInOut(board.IO4)
touch.switch_to_input()
ble=None
ble_keyboard=None
usb_keyboard=None
for device in usb_hid.devices:
 if device.usage_page==1 and device.usage==6:
  usb_keyboard=device
  break
management=None
output_device=None
state='STARTING'
_pm_enabled=False
_pm_available=hasattr(espidf,'set_auto_light_sleep')

def log(event):
 print('LS2',event)

class PendingInput:
 def __init__(self):
  self.deadline=None
 def submit(self,now):
  if self.deadline is not None: return False
  self.deadline=now+CONNECT_TIMEOUT
  return True
 def poll(self,now,ready):
  if self.deadline is None: return None
  if now>=self.deadline:
   self.deadline=None; return 'expired'
  if ready:
   return 'ready'
  return None

class ConnectionGate:
 def __init__(self):
  self.peer=None; self.since=None
 def update(self,now,peer):
  if peer is None:
   self.peer=None; self.since=None; return False
  if peer is not self.peer:
   self.peer=peer; self.since=now
  return now-self.since>=SETTLE_SECONDS


def char(c):
 if 'a'<=c<='z': return (ord(c)-ord('a')+4,False)
 if 'A'<=c<='Z': return (ord(c)-ord('A')+4,True)
 if '1'<=c<='9': return (ord(c)-ord('1')+30,False)
 if c=='0': return (39,False)
 plain=' \t-=[]\\;\'`,./'; codes=(44,43,45,46,47,48,49,51,52,53,54,55,56)
 if c in plain: return (codes[plain.index(c)],False)
 shifted='!@#$%^&*()_+{}|:"~<>?'; shifted_codes=(30,31,32,33,34,35,36,37,38,39,45,46,47,48,49,51,52,53,54,55,56)
 if c in shifted: return (shifted_codes[shifted.index(c)],True)
 raise ValueError('Unsupported character')


KEY_CODES={'BACKSPACE': 42, 'DELETE': 76, 'ESCAPE': 41, 'ENTER': 40, 'TAB': 43, 'SPACE': 44, 'UP_ARROW': 82, 'DOWN_ARROW': 81, 'LEFT_ARROW': 80, 'RIGHT_ARROW': 79, 'HOME': 74, 'END': 77, 'PAGE_UP': 75, 'PAGE_DOWN': 78, 'INSERT': 73, 'F1': 58, 'F2': 59, 'F3': 60, 'F4': 61, 'F5': 62, 'F6': 63, 'F7': 64, 'F8': 65, 'F9': 66, 'F10': 67, 'F11': 68, 'F12': 69}

def macro():
 try:
  if management is not None:
   from zw111_manager import load_macro
   config=json.loads(load_macro().decode())
  else:
   with open('/macro.json','r') as f: config=json.load(f)
  if config.get('version')!=1 or not config.get('enabled',False): return
  steps=config['steps']
  if not isinstance(steps,list) or len(steps)>30: return
  for s in steps:
   delay=float(s.get('delay',0))
   if not 0<=delay<=60: return
   action=s.get('type'); text=s.get('text',''); speed=float(s.get('interval',.1))
   if action not in ('wait','text','enter','key') or not 0<=speed<=2 or len(text)>200: return
   if action=='key' and s.get('key') not in KEY_CODES: return
   if action=='text':
    for c in text: char(c)
  for s in steps:
   time.sleep(float(s.get('delay',0)))
   if s['type']=='text':
    for c in s.get('text',''):
     code,shift=char(c); report(code,shift); time.sleep(float(s.get('interval',.1)))
   elif s['type']=='enter': report(40)
   elif s['type']=='key': report(KEY_CODES[s['key']])
 except Exception:
  log('MACRO_FAILED'); raise


serial_command=b''
def handle_control():
 global serial_command, _pm_enabled
 port=usb_cdc.console
 if port is None: return
 count=port.in_waiting
 if not count: return
 data=port.read(min(count,64)) or b''
 for c in data:
  if c==10:
   line=serial_command; serial_command=b''
   if line==b'@ZW111:CHECK':
    connected=bool(ble is not None and any(c.paired for c in ble.connections))
    print('__ZW111_BLE_READY__' if connected else '__ZW111_BLE_NOT_PAIRED__')
   elif line==b'@ZW111:VERSION':
    print('__ZW111_VERSION__LS2_KEYBOARD_TRANSPORT')
   elif line==b'@ZW111:PMTEST':
    if not _pm_available:
     print('__ZW111_PMTEST__UNAVAILABLE'); continue
    before=espidf.light_sleep_stats()
    try:
     idle_wait(force_test=True)
    finally:
     espidf.set_auto_light_sleep(False); _pm_enabled=False
    after=espidf.light_sleep_stats()
    print('__ZW111_PMTEST__', after[1]-before[1], after[2]-before[2], after[3]-before[3], after[4:])
   elif line==b'@ZW111:PMSTATS':
    print('__ZW111_PM__', espidf.light_sleep_stats() if _pm_available else 'UNAVAILABLE')
   elif line==b'@ZW111:STATUS':
    print('__ZW111_STATE__'+state)
   elif line in (b'@ZW111:KEY29',b'@ZW111:KEY56'):
    try:
     keyboard=ble_keyboard if paired_peer() is not None else None
     if keyboard is None:
      print('__ZW111_BLE_NOT_PAIRED__'); continue
     key=29 if line.endswith(b'29') else 56
     keyboard.send_report(bytes((0,0,key,0,0,0,0,0)))
     time.sleep(.1); keyboard.send_report(bytes(8))
     print('__ZW111_KEY_OK__')
    except Exception as e: print('__ZW111_KEY_ERROR__',e)
  elif len(serial_command)<80: serial_command+=bytes((c,))
  else: serial_command=b''


# Capture before loading BLE libraries, so the waking press is not delayed by BLE startup.
pending=PendingInput()
gate=ConnectionGate()
last_activity=time.monotonic()
wait_release=False
last_led_off=0
wake_press=isinstance(alarm.wake_alarm,alarm.pin.PinAlarm) or touch.value

def led_off():
 global last_led_off
 r=cmd(bytes((0x3c,4,0,0,0)))
 last_led_off=time.monotonic()
 return bool(r and r[0]==0)

green_until=0

def verify_press():
 global state, green_until, _pm_enabled
 if _pm_enabled:
  espidf.set_auto_light_sleep(False)
  _pm_enabled=False
 state='VERIFYING'
 end=time.monotonic()+2.5
 while time.monotonic()<end:
  r=cmd(b'\x01')
  if r and r[0]==0: break
  if not touch.value: return False
  time.sleep(.06)
 else: return False
 r=cmd(b'\x02\x01')
 if not r or r[0]!=0: log('FEATURE_FAILED'); led_off(); return False
 r=cmd(b'\x04\x01\x00\x00\x00\x64')
 matched=bool(r and len(r)==5 and r[0]==0)
 log('MATCH' if matched else 'NO_MATCH')
 if matched:
  green_until=flash_green(cmd)
  pulse_vibration(match_output,vibration_setting)
 else: time.sleep(.3); led_off()
 return matched

led_off()

if wake_press:
 wait_release=True
 if verify_press(): pending.submit(time.monotonic())

try:
 from adafruit_ble import BLERadio
 from adafruit_ble.advertising import Advertisement
 from adafruit_ble.advertising.standard import ProvideServicesAdvertisement
 from adafruit_ble.services.standard.hid import HIDService
 hid=HIDService()
 try:
  from zw111_manager import ManagementService
  import zw111_wire as wire

  class LightManagementService(ManagementService):
   def _execute(self, op, offset, data, now, cmd, key_codes, char):
    if self.authenticated and (op in (wire.S3_MODE_SET, wire.MACRO_SAVE)
         or op == wire.FP and data and data[0] not in (0x0f, 0x1f, 0x35)):
     pending.deadline=None
    return super()._execute(op, offset, data, now, cmd, key_codes, char)

  management=LightManagementService()
  management.vibration_level=vibration_level
 except Exception as e:
  print('MANAGEMENT_INIT_FAILED', type(e).__name__, str(e))
 adv=ProvideServicesAdvertisement(hid, management) if management else ProvideServicesAdvertisement(hid); adv.appearance=961
 response=Advertisement(); response.complete_name=_zw111_bluetooth_name()
 ble=BLERadio(); ble.name=_zw111_bluetooth_name()
 ble_keyboard=next(d for d in hid.devices if d.usage_page==1 and d.usage==6)
 ble.start_advertising(adv,response)
 log('ADVERTISING')
except Exception:
 log('BLE_INIT_FAILED')
 ble=None

def paired_peer():
 if ble is not None:
  for c in ble.connections:
   if c.connected and c.paired: return c
 return None

def active_usb_keyboard():
 return usb_keyboard if supervisor.runtime.usb_connected else None

def maintain_ble():
 if ble is not None and not ble.connected and not ble.advertising:
  try: ble.start_advertising(adv,response)
  except Exception: log('ADVERTISING_FAILED')

def management_active():
 if management is None or ble is None: return False
 try:
  return management.poll(ble,cmd,KEY_CODES,char)
 except Exception:
  return False

def report(key,shift=False):
 # Lock one transport for the entire macro. Never fall back to USB midway.
 if output_device is ble_keyboard and paired_peer() is None:
  raise RuntimeError('BLE disconnected during macro')
 output_device.send_report(bytes((2 if shift else 0,0,key,0,0,0,0,0)))
 time.sleep(.035)
 output_device.send_report(bytes(8))

def idle_wait(force_test=False):
 global touch, state, _pm_enabled
 # Keep USB control commands responsive. Off USB, use pin/timer alarms instead
 # of image-acquisition polling. Patched IDF supports real automatic sleep.
 _board_led.value=False
 if supervisor.runtime.usb_connected and not force_test:
  if _pm_enabled:
   espidf.set_auto_light_sleep(False); _pm_enabled=False
  time.sleep(.03)
  return False
 if not _pm_available:
  state='PM_UNAVAILABLE'; time.sleep(.03); return False
 if not _pm_enabled:
  espidf.set_auto_light_sleep(True); _pm_enabled=True
  log('CHIP_AUTO_ENABLED')
 touch.deinit()
 try:
  wake=alarm.pin.PinAlarm(pin=board.IO4,value=True,pull=True)
  maintenance=alarm.time.TimeAlarm(monotonic_time=time.monotonic()+2)
  state='CHIP_LIGHT_WAIT'
  reason=alarm.light_sleep_until_alarms(wake,maintenance)
  return isinstance(reason,alarm.pin.PinAlarm)
 finally:
  touch=digitalio.DigitalInOut(board.IO4)
  touch.switch_to_input()
  _board_led.value=False
  state='IDLE'

state='IDLE'
log('RUNNING')
while True:
 maintain_ble(); handle_control()
 if management_active():
  wait_release=touch.value
  time.sleep(.02); continue
 now=time.monotonic()
 peer=paired_peer()
 ble_ready=gate.update(now,peer)
 ready_keyboard=active_usb_keyboard() or (ble_keyboard if ble_ready else None)
 if pending.deadline is not None:
  state='WAITING_BLE'
  outcome=pending.poll(now,ready_keyboard is not None)
  if outcome=='ready':
   state='SENDING'; output_device=ready_keyboard
   try:
    output_device.send_report(bytes(8))
    if output_device is ble_keyboard:
     time.sleep(.3)
     if peer is None or paired_peer() is not peer: raise RuntimeError('BLE connection changed')
   except (OSError,RuntimeError):
    gate.update(time.monotonic(),None)
    output_device=None
    time.sleep(.05); continue
   pending.deadline=None
   try:
    log('MACRO_USB' if output_device is usb_keyboard else 'MACRO_BLE')
    macro()
    log('MACRO_FINISHED')
   except Exception as error: print('LS2 SEND_FAILED_NO_RETRY',type(error).__name__)
   finally:
    try: output_device.send_report(bytes(8))
    except Exception: pass
    output_device=None
   state='IDLE'
  elif outcome=='expired':
   log('CONNECTION_TIMEOUT'); state='IDLE'
  _board_led.value=False
  time.sleep(.05); continue
 if green_until:
  if now<green_until:
   time.sleep(.04); continue
  green_until=0
  led_off()
 woke_touch=False
 if not touch.value:
  wait_release=False
  if now-last_led_off>=2: led_off()
  woke_touch=idle_wait()
 if (woke_touch or touch.value) and not wait_release:
  wait_release=True
  try:
   if verify_press(): pending.submit(time.monotonic())
  finally:
   if not green_until: led_off()
   _board_led.value=False; state='IDLE'
 else:
  time.sleep(.03)
