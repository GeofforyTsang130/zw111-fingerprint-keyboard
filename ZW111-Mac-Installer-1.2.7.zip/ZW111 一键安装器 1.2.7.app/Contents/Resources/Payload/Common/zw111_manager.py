"""CircuitPython service for the companion app, on the existing HID connection."""

import json
import os
import time

import _bleio
import storage
import supervisor
from adafruit_ble.characteristics import Attribute, Characteristic, ComplexCharacteristic
from adafruit_ble.services import Service
from adafruit_ble.uuid import VendorUUID

import zw111_wire as wire

MACRO = "/macro.json"
PREVIOUS = "/.macro-previous"
STAGED = "/.macro-staged"


def load_macro():
    for path in (MACRO, PREVIOUS):
        try:
            with open(path, "rb") as source:
                return source.read(wire.MAX_MACRO + 1)
        except OSError as exc:
            if exc.errno != 2:
                raise
    return b'{"version":1,"enabled":false,"steps":[]}'


def save_macro(data):
    # A USB filesystem mounted by the host must stay under host ownership.
    if supervisor.runtime.usb_connected:
        raise RuntimeError("USB storage active")
    storage.remount("/", readonly=False)
    try:
        with open(STAGED, "wb") as output:
            output.write(data)
        os.sync()
        if MACRO[1:] in os.listdir("/"):
            if PREVIOUS[1:] in os.listdir("/"):
                os.remove(PREVIOUS)
            os.rename(MACRO, PREVIOUS)
        try:
            os.rename(STAGED, MACRO)
        except OSError:
            if PREVIOUS[1:] in os.listdir("/"):
                os.rename(PREVIOUS, MACRO)
            raise
        os.sync()
    finally:
        storage.remount("/", readonly=True)


def validate_macro(data, key_codes, char):
    config = json.loads(data.decode())
    if config["version"] != 1 or not isinstance(config["enabled"], bool):
        raise ValueError("invalid macro settings")
    steps = config["steps"]
    if not isinstance(steps, list) or len(steps) > 30 or (config["enabled"] and not steps):
        raise ValueError("invalid step count")
    for step in steps:
        if not 0 <= float(step.get("delay", 0)) <= 60:
            raise ValueError("invalid wait")
        action = step["type"]
        if action == "text":
            value = step["text"]
            if not isinstance(value, str) or not 1 <= len(value) <= 200:
                raise ValueError("invalid text")
            if not 0 <= float(step.get("interval", .1)) <= 2:
                raise ValueError("invalid speed")
            for letter in value:
                char(letter)
        elif action == "key":
            if step["key"] not in key_codes:
                raise ValueError("invalid key")
        elif action not in ("wait", "enter"):
            raise ValueError("invalid action")


def read_module_metadata(cmd, data):
    parameter = data == b"\x0f"
    handshake = data == b"\x35"
    if not (parameter or handshake or data[:1] == b"\x1f"):
        return cmd(data)
    deadline = time.monotonic() + 2.3
    for attempt in range(6):
        if time.monotonic() >= deadline:
            break
        request = b"\x35" if parameter and attempt == 2 else data
        reply = cmd(request)
        if reply and reply[0] == 0:
            if parameter and 17 <= len(reply) < 33:
                samples = int.from_bytes(reply[1:3], "big")
                capacity = int.from_bytes(reply[5:7], "big")
                if 1 <= samples <= 16 and 1 <= capacity <= 1024:
                    return reply
            elif handshake and len(reply) == 1:
                return reply
            elif not parameter and not handshake and len(reply) == 33:
                return reply
        elif reply and len(reply) == 1 and reply[0] not in (2, 9) and request == data:
            return reply
        time.sleep(.035)
    return None


def capture_reply(cmd, data):
    # Capture polling is repeatable; never retry feature extraction or storage here.
    deadline = time.monotonic() + 2.3
    for _ in range(2):
        reply = cmd(data)
        if reply and len(reply) == 1 and reply[0] != 9:
            return reply
        if time.monotonic() >= deadline:
            break
        time.sleep(.035)
    return None


class ManagementService(Service):
    uuid = VendorUUID(wire.SERVICE)
    request = ComplexCharacteristic(
        uuid=VendorUUID(wire.REQUEST), properties=Characteristic.WRITE,
        read_perm=Attribute.NO_ACCESS, write_perm=Attribute.ENCRYPT_NO_MITM,
        max_length=20,
    )
    response = ComplexCharacteristic(
        uuid=VendorUUID(wire.RESPONSE), properties=Characteristic.READ,
        read_perm=Attribute.ENCRYPT_NO_MITM, write_perm=Attribute.NO_ACCESS,
        max_length=20, initial_value=b"\0\0",
    )

    def __init__(self):
        self.reload_at = 0
        with open("/.zw111-management-key", "rb") as source:
            self.secret = source.read(33)
        if len(self.secret) != 32:
            raise ValueError("invalid management key")
        super().__init__()
        self.incoming = _bleio.PacketBuffer(self.request, buffer_size=4)
        self.response.value = b"\0\0"
        self.frame = bytearray(20)
        self.reset()

    def reset(self):
        self.deadline = 0
        self.nonces = None
        self.authenticated = False
        self.upload = None
        self.download = b""
        self.peer = None
        self.next_id = None

    def _execute(self, op, offset, data, now, cmd, key_codes, char):
        if op == wire.HELLO and len(data) == 16 and not self.authenticated:
            nonce = os.urandom(16)
            self.nonces = (data, nonce)
            self.download = nonce + wire.proof(self.secret, b"device", data, nonce)
            self.deadline = now + 8
            return 0, len(self.download).to_bytes(2, "big")
        if op == wire.READ and (self.nonces or self.authenticated):
            if self.authenticated:
                self.deadline = now + 12
            return 0, self.download[offset:offset + 18]
        if op == wire.AUTH and self.nonces and not self.authenticated:
            expected = wire.proof(self.secret, b"mac", *self.nonces)
            self.nonces = None
            self.download = b""
            mismatch = len(data) ^ len(expected)
            for a, b in zip(data, expected):
                mismatch |= a ^ b
            if mismatch:
                self.deadline = 0
                return 1, b""
            self.authenticated = True
            self.deadline = now + 12
            return 0, b""
        if not self.authenticated:
            return 1, b""
        self.deadline = now + 12
        if op == wire.END and not data:
            return 0, b""
        if op == wire.REBOOT and not offset and not data:
            self.reload_at = time.monotonic() + 0.8
            return 0, b""
        if op in (wire.S3_MODE_GET, wire.S3_MODE_SET):
            try:
                import zw111_s3_mode as modes
            except ImportError:
                return 4, b""
            if not offset and op == wire.S3_MODE_GET and not data:
                return 0, modes.read_mode()
            if not offset and op == wire.S3_MODE_SET and data in modes.MODES:
                if data != modes.read_mode():
                    if modes.supervisor.runtime.usb_connected:
                        return 5, b""
                    modes.save_mode(data)
                    self.reload_at = time.monotonic() + 3
                return 0, modes.read_mode()
            return 4, b""
        if op in (wire.MODE_GET, wire.MODE_SET):
            profile = getattr(self, "work_profile", None)
            if profile is not None and not offset:
                if op == wire.MODE_GET and not data:
                    return 0, profile().encode()
                if op == wire.MODE_SET and data in (b"A", b"L"):
                    return 0, profile(data.decode()).encode()
            return 4, b""
        if op in (wire.VIBRATION_GET, wire.VIBRATION_SET):
            level = getattr(self, "vibration_level", None)
            if level is not None and not offset:
                if op == wire.VIBRATION_GET and not data:
                    return 0, bytes((level(),))
                if op == wire.VIBRATION_SET and len(data) == 1 and data[0] in (1, 2, 3):
                    try:
                        return 0, bytes((level(data[0]),))
                    except RuntimeError as exc:
                        if "USB" in str(exc):
                            return 5, b""
                        raise
            return 4, b""
        if op == wire.FP and data and wire.FP_LENGTHS.get(data[0]) == len(data):
            if data in (b"\x01", b"\x29"):
                result = capture_reply(cmd, data)
            elif getattr(self, "work_profile", None) is not None:
                result = cmd(data)
            else:
                result = read_module_metadata(cmd, data)
            if result is None:
                return 3, b""
            self.download = result
            return 0, len(result).to_bytes(2, "big")
        if op == wire.MACRO_GET and not data:
            self.download = load_macro()
            if len(self.download) > wire.MAX_MACRO:
                self.download = b""
                return 4, b""
            return 0, len(self.download).to_bytes(2, "big")
        if op == wire.MACRO_BEGIN and not data:
            self.upload = bytearray()
            return 0, b""
        if op == wire.MACRO_CHUNK and self.upload is not None and data:
            if offset == len(self.upload) and offset + len(data) <= wire.MAX_MACRO:
                self.upload.extend(data)
                return 0, b""
        if op == wire.MACRO_SAVE and self.upload is not None and not data:
            upload = self.upload
            self.upload = None
            if offset != len(upload):
                return 4, b""
            try:
                validate_macro(upload, key_codes, char)
            except (ValueError, KeyError, TypeError, AttributeError, OverflowError):
                return 4, b""
            if supervisor.runtime.usb_connected:
                return 5, b""
            save_macro(upload)
            return 0, b""
        return 4, b""

    def poll(self, ble, cmd, key_codes, char):
        now = time.monotonic()
        if self.reload_at and now >= self.reload_at:
            import microcontroller
            self.reload_at = 0
            if supervisor.runtime.usb_connected:
                supervisor.reload()
            else:
                for connection in ble.connections:
                    try:
                        connection.disconnect()
                    except (OSError, RuntimeError):
                        pass
                time.sleep(.25)
                microcontroller.reset()
        peers = ble.connections
        peer = peers[0] if len(peers) == 1 and peers[0].paired else None
        if peer is not self.peer or (self.deadline and now >= self.deadline):
            # Keep only an empty status in the readable characteristic.
            self.reset()
            self.response.value = b"\0\0"
            self.peer = peer
        count = self.incoming.readinto(self.frame)
        if count >= 4 and peer is not None:
            request_id, op = self.frame[:2]
            if not request_id:
                return self.authenticated or self.nonces is not None
            # A new challenge from the same bonded host also recovers an abandoned session.
            if op == wire.HELLO:
                self.reset()
                self.peer = peer
            elif request_id != self.next_id:
                return self.authenticated or self.nonces is not None
            self.next_id = request_id % 255 + 1
            offset = int.from_bytes(self.frame[2:4], "big")
            try:
                status, payload = self._execute(op, offset, bytes(self.frame[4:count]),
                                                now, cmd, key_codes, char)
            except Exception:
                status, payload = 2, b""
            self.response.value = bytes((request_id, status)) + payload
            if op == wire.END and status == 0:
                self.reset()
                self.peer = peer
                return True
        return self.authenticated or self.nonces is not None
