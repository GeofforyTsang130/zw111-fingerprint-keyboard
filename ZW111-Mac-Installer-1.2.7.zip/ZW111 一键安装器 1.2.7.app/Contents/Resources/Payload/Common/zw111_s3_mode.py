import os
import storage
import supervisor

MODE_FILE = "/.zw111-s3-mode"
PREVIOUS = "/.zw111-s3-mode-previous"
STAGED = "/.zw111-s3-mode-next"
MODES = (b"0", b"1", b"2", b"3")


def read_mode():
    for path in (MODE_FILE, PREVIOUS):
        try:
            with open(path, "rb") as source:
                value = source.read(2).strip()
        except OSError:
            continue
        if value in MODES:
            return value
    return b"0"


def save_mode(value):
    if value not in MODES:
        raise ValueError("Invalid S3 work mode")
    if supervisor.runtime.usb_connected:
        raise RuntimeError("USB owns storage")
    storage.remount("/", readonly=False)
    try:
        with open(STAGED, "wb") as target:
            target.write(value)
        os.sync()
        files = os.listdir("/")
        if MODE_FILE[1:] in files:
            if PREVIOUS[1:] in files:
                os.remove(PREVIOUS)
            os.rename(MODE_FILE, PREVIOUS)
        os.rename(STAGED, MODE_FILE)
        os.sync()
        if read_mode() != value:
            raise OSError("S3 work mode readback failed")
    finally:
        storage.remount("/", readonly=True)
