def _zw111_bluetooth_name():
 try:
  with open('/.zw111-ble-name','rb') as source:
   raw=source.read(25)
  name=raw.decode().strip()
  if name and len(raw)<=24 and all(ord(c)>=32 and ord(c)!=127 for c in name):
   return name
 except (OSError,UnicodeError):
  pass
 return 'zizizi'

from zw111_match_led import flash_green, LIGHT_OFF, WAIT_LIGHT
from zw111_sensor import FingerprintUART
from zw111_vibration import init_vibration_output, read_vibration_level, save_vibration_level, pulse_vibration
import supervisor
import time, board, busio, usb_hid, usb_cdc, json
import digitalio, supervisor
supervisor.runtime.rgb_status_brightness=0
_board_led=digitalio.DigitalInOut(board.IO48)
_board_led.switch_to_output(value=False)
match_output=init_vibration_output(digitalio,board.IO3)
vibration_setting=read_vibration_level()
def vibration_level(selected=None):
 global vibration_setting
 if selected is not None and selected!=vibration_setting:
  save_vibration_level(selected)
  vibration_setting=selected
 return vibration_setting
u=busio.UART(board.IO43,board.IO44,baudrate=57600,timeout=0)
cmd=FingerprintUART(u).command
touch=digitalio.DigitalInOut(board.IO4)
touch.switch_to_input()
k=next(d for d in usb_hid.devices if d.usage_page==1 and d.usage==6)
ble=None
ble_keyboard=None
management=None
try:
 from adafruit_ble import BLERadio
 from adafruit_ble.advertising import Advertisement
 from adafruit_ble.advertising.standard import ProvideServicesAdvertisement
 from adafruit_ble.services.standard.hid import HIDService
 hid=HIDService()
 try:
  from zw111_manager import ManagementService
  import zw111_wire as wire

  class ContinuousManagementService(ManagementService):
   def _execute(self, op, offset, data, now, cmd, key_codes, char):
    global pending_until
    if self.authenticated and (op in (wire.S3_MODE_SET, wire.MACRO_SAVE)
         or op == wire.FP and data and data[0] not in (0x0f, 0x1f, 0x35)):
     pending_until=0
    return super()._execute(op, offset, data, now, cmd, key_codes, char)

  management=ContinuousManagementService()
  management.vibration_level=vibration_level
 except Exception as e:
  print('MANAGEMENT_INIT_FAILED', type(e).__name__, str(e))
 adv=ProvideServicesAdvertisement(hid, management) if management else ProvideServicesAdvertisement(hid)
 adv.appearance=961
 response=Advertisement()
 response.complete_name=_zw111_bluetooth_name()
 ble=BLERadio()
 ble.name=_zw111_bluetooth_name()
 ble_keyboard=next(d for d in hid.devices if d.usage_page==1 and d.usage==6)
 ble.start_advertising(adv, response)
 print('BLE keyboard advertising')
except Exception as e:
 print('BLE unavailable; USB remains active:', e)
 ble=None
 ble_keyboard=None

def maintain_ble():
 if ble is None: return
 try:
  if not ble.connected and not ble.advertising:
   ble.start_advertising(adv,response)
 except Exception as e: print('BLE advertising error:',e)


def management_active():
 if management is None or ble is None: return False
 try:
  return management.poll(ble,cmd,KEY_CODES,char)
 except Exception:
  return False

output_device=None

def paired_peer():
 if ble is not None:
  for peer in ble.connections:
   if peer.connected and peer.paired: return peer
 return None

def report(key,shift=False):
 if output_device is None or (output_device is ble_keyboard and paired_peer() is None):
  raise RuntimeError('Keyboard disconnected')
 output_device.send_report(bytes((2 if shift else 0,0,key,0,0,0,0,0)))
 time.sleep(.02)
 output_device.send_report(bytes(8))

def char(c):
 if 'a'<=c<='z': return (ord(c)-ord('a')+4,False)
 if 'A'<=c<='Z': return (ord(c)-ord('A')+4,True)
 if '1'<=c<='9': return (ord(c)-ord('1')+30,False)
 if c=='0': return (39,False)
 plain=' \t-=[]\\;\'`,./'; codes=(44,43,45,46,47,48,49,51,52,53,54,55,56)
 if c in plain: return (codes[plain.index(c)],False)
 shifted='!@#$%^&*()_+{}|:"~<>?'; shifted_codes=(30,31,32,33,34,35,36,37,38,39,45,46,47,48,49,51,52,53,54,55,56)
 if c in shifted: return (shifted_codes[shifted.index(c)],True)
 raise ValueError('Unsupported character')

KEY_CODES={'BACKSPACE': 42, 'DELETE': 76, 'ESCAPE': 41, 'ENTER': 40, 'TAB': 43, 'SPACE': 44, 'UP_ARROW': 82, 'DOWN_ARROW': 81, 'LEFT_ARROW': 80, 'RIGHT_ARROW': 79, 'HOME': 74, 'END': 77, 'PAGE_UP': 75, 'PAGE_DOWN': 78, 'INSERT': 73, 'F1': 58, 'F2': 59, 'F3': 60, 'F4': 61, 'F5': 62, 'F6': 63, 'F7': 64, 'F8': 65, 'F9': 66, 'F10': 67, 'F11': 68, 'F12': 69}

def macro():
 try:
  if management is not None:
   from zw111_manager import load_macro
   config=json.loads(load_macro().decode())
  else:
   with open('/macro.json','r') as f: config=json.load(f)
  if config.get('version')!=1 or not config.get('enabled',False): return
  steps=config['steps']
  if not isinstance(steps,list) or len(steps)>30: return
  for s in steps:
   delay=float(s.get('delay',0))
   if not 0<=delay<=60: return
   action=s.get('type'); text=s.get('text',''); speed=float(s.get('interval',.1))
   if action not in ('wait','text','enter','key') or not 0<=speed<=2 or len(text)>200: return
   if action=='key' and s.get('key') not in KEY_CODES: return
   if action=='text':
    for c in text: char(c)
  for s in steps:
   time.sleep(float(s.get('delay',0)))
   if s['type']=='text':
    for c in s.get('text',''):
     code,shift=char(c); report(code,shift); time.sleep(float(s.get('interval',.1)))
   elif s['type']=='enter': report(40)
   elif s['type']=='key': report(KEY_CODES[s['key']])
 except Exception as e: print('MACRO ERROR:',e)

serial_command=b''
def handle_control():
 global serial_command
 port=usb_cdc.console
 if port is None: return
 count=port.in_waiting
 if not count: return
 data=port.read(min(count,64)) or b''
 for c in data:
  if c==10:
   line=serial_command; serial_command=b''
   if line==b'@ZW111:CHECK':
    connected=bool(ble is not None and any(c.paired for c in ble.connections))
    print('__ZW111_BLE_READY__' if connected else '__ZW111_BLE_NOT_PAIRED__')
   elif line in (b'@ZW111:KEY29',b'@ZW111:KEY56'):
    try:
     if ble is None or ble_keyboard is None or not any(c.paired for c in ble.connections):
      print('__ZW111_BLE_NOT_PAIRED__'); continue
     key=29 if line.endswith(b'29') else 56
     ble_keyboard.send_report(bytes((0,0,key,0,0,0,0,0)))
     time.sleep(.1); ble_keyboard.send_report(bytes(8))
     print('__ZW111_KEY_OK__')
    except Exception as e: print('__ZW111_KEY_ERROR__',e)
  elif len(serial_command)<80: serial_command+=bytes((c,))
  else: serial_command=b''

print('Fingerprint macro ready: release finger first')
wait_release=True
led_dark=False
last_led_off=0
was_touching=False
green_until=0
pending_until=0
ready_peer=None
ready_since=0
while True:
 maintain_ble()
 handle_control()
 if management_active():
  wait_release=True
  time.sleep(.02); continue
 now=time.monotonic()
 if green_until and now>=green_until:
  green_until=0
  cmd(LIGHT_OFF)
 peer=paired_peer()
 if peer is not ready_peer:
  ready_peer=peer
  ready_since=now
 if pending_until and now>=pending_until:
  pending_until=0
  print('KEYBOARD_RECONNECT_TIMEOUT')
 if pending_until:
  if supervisor.runtime.usb_connected:
   output_device=k
  elif peer is not None and now-ready_since>=2:
   output_device=ble_keyboard
  if output_device is not None:
   pending_until=0
   try:
    output_device.send_report(bytes(8))
    print('MACRO_USB' if output_device is k else 'MACRO_BLE')
    macro()
   except (OSError,RuntimeError) as error:
    print('KEYBOARD_SEND_FAILED',error)
   finally:
    output_device=None
  else:
   time.sleep(.04); continue
 if green_until:
  time.sleep(.04); continue
 if not touch.value:
  wait_release=False
  if was_touching:
   led_dark=False
   was_touching=False
  if not led_dark or time.monotonic()-last_led_off>=2:
   off=cmd(bytes((0x3c,0x04,0,0,0)))
   led_dark=bool(off and off[0]==0)
   last_led_off=time.monotonic()
 elif not wait_release:
  was_touching=True
  led_dark=False
  wait_release=True
  r=cmd(b'\x01')
  if r!=b'\x00': continue
  r=cmd(b'\x02\x01')
  if r==b'\x00':
   r=cmd(b'\x04\x01\x00\x00\x00\x64')
   if r and len(r)==5 and r[0]==0:
    green_until=flash_green(cmd)
    pulse_vibration(match_output,vibration_setting)
    print('MATCH',int.from_bytes(r[1:3],'big')); pending_until=time.monotonic()+15
   else: print('NO MATCH')
 time.sleep(.03)
