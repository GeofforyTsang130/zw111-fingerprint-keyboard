"""Shared packet layout and authentication for the ZW111 management service."""

SERVICE = "7f257700-6fba-4987-ac62-b9a8b8b304bb"
REQUEST = "7f257701-6fba-4987-ac62-b9a8b8b304bb"
RESPONSE = "7f257702-6fba-4987-ac62-b9a8b8b304bb"
HELLO, AUTH, END, FP, MACRO_GET, MACRO_BEGIN, MACRO_CHUNK, MACRO_SAVE, READ = range(1, 10)
MODE_GET, MODE_SET = 10, 11
S3_MODE_GET, S3_MODE_SET = 12, 13
VIBRATION_GET, VIBRATION_SET = 14, 15
REBOOT = 16
MAX_MACRO = 12000
# Limited to the fingerprint commands the desktop UI already uses.
# Store (0x06): opcode, buffer ID, and two-byte template slot.
FP_LENGTHS = {0x01: 1, 0x02: 2, 0x04: 6, 0x05: 1, 0x06: 4, 0x0C: 5,
              0x0F: 1, 0x1F: 2, 0x29: 1, 0x35: 1}


def proof(secret, role, client_nonce, device_nonce):
    from hashlib import new
    padded = secret + bytes(64 - len(secret))
    inner = new("sha256")
    inner.update(bytes(x ^ 0x36 for x in padded))
    inner.update(role + client_nonce + device_nonce)
    outer = new("sha256")
    outer.update(bytes(x ^ 0x5c for x in padded))
    outer.update(inner.digest())
    return outer.digest()[:16]
