"""S3 GPIO3 vibration pulse and persistent level settings."""

import os
import time

import storage
import supervisor

VIBRATION_FILE = "/.zw111-vibration"
VIBRATION_PREVIOUS = "/.zw111-vibration-prev"
VIBRATION_STAGED = "/.zw111-vibration-stage"


def read_vibration_level():
    for path in (VIBRATION_FILE, VIBRATION_PREVIOUS):
        try:
            with open(path, "rb") as source:
                value = source.read(2)
            if value in (b"1", b"2", b"3"):
                return int(value)
        except OSError:
            pass
    return 1


def save_vibration_level(level):
    if level not in (1, 2, 3):
        raise ValueError("invalid vibration level")
    if supervisor.runtime.usb_connected:
        raise RuntimeError("USB storage active")
    storage.remount("/", readonly=False)
    try:
        with open(VIBRATION_STAGED, "wb") as output:
            output.write(str(level).encode())
        os.sync()
        names = os.listdir("/")
        if VIBRATION_FILE[1:] in names:
            if VIBRATION_PREVIOUS[1:] in names:
                os.remove(VIBRATION_PREVIOUS)
            os.rename(VIBRATION_FILE, VIBRATION_PREVIOUS)
        try:
            os.rename(VIBRATION_STAGED, VIBRATION_FILE)
        except OSError:
            if VIBRATION_PREVIOUS[1:] in os.listdir("/") and VIBRATION_FILE[1:] not in os.listdir("/"):
                os.rename(VIBRATION_PREVIOUS, VIBRATION_FILE)
            raise
        os.sync()
        if read_vibration_level() != level:
            raise OSError("vibration readback failed")
    finally:
        storage.remount("/", readonly=True)


def init_vibration_output(digitalio, pin):
    output = digitalio.DigitalInOut(pin)
    output.deinit()  # Calls reset_pin_number -> gpio_hold_dis(pin) to clear any deep-sleep hold.
    output = digitalio.DigitalInOut(pin)
    output.switch_to_output(value=False)
    return output


def pulse_vibration(output, level):
    output.value = True
    try:
        time.sleep(level / 10)
    finally:
        output.value = False
