from zw111_s3_mode import read_mode

mode = read_mode()
if mode == b"1":
    import zw111_s3_profile1
elif mode == b"2":
    import zw111_s3_profile2
elif mode == b"3":
    import zw111_s3_profile3
else:
    import zw111_s3_profile0
