def _zw111_bluetooth_name():
 try:
  with open('/.zw111-ble-name','rb') as source:
   raw=source.read(25)
  name=raw.decode().strip()
  if name and len(raw)<=24 and all(ord(c)>=32 and ord(c)!=127 for c in name):
   return name
 except (OSError,UnicodeError):
  pass
 return 'zizizi'

# ZW111 deep sleep: capture first, then reconnect BLE.
import time
python_started_ns = time.monotonic_ns()
import board, busio, digitalio, alarm, supervisor
supervisor.runtime.rgb_status_brightness=0
_board_led=digitalio.DigitalInOut(board.IO48)
_board_led.switch_to_output(value=False)
IDLE_SECONDS=30
CONNECT_TIMEOUT=25
SETTLE_SECONDS=2.0
u=busio.UART(board.IO43,board.IO44,baudrate=57600,timeout=0)
touch=digitalio.DigitalInOut(board.IO4)
touch.switch_to_input()
ble=None
ble_keyboard=None
management=None
output_device=None
state='STARTING'


wake_events_ns = {}
wake_alarm = alarm.wake_alarm
deep_wake = isinstance(wake_alarm, alarm.pin.PinAlarm) and wake_alarm.pin is board.IO4
wake_press = isinstance(wake_alarm, alarm.pin.PinAlarm) or touch.value
wake_offset_ns = None
tracing_hid = False
last_led_off = 0
blue_feedback_until = 0


def note_wake(stage):
    if deep_wake and stage not in wake_events_ns:
        wake_events_ns[stage] = time.monotonic_ns()


def wake_trace():
    if not deep_wake:
        return {}
    baseline = -wake_offset_ns if wake_offset_ns is not None else python_started_ns
    return {
        "origin": "rtc_wake_stub" if wake_offset_ns is not None else "python_entry",
        "stages_ms": {stage: (stamp - baseline) // 1000000
                      for stage, stamp in wake_events_ns.items()},
    }


if deep_wake:
    wake_events_ns["python_start"] = python_started_ns
    note_wake("uart_ready")


def uart_read_exact(size, deadline):
    result = bytearray()
    while len(result) < size and time.monotonic() < deadline:
        chunk = u.read(size - len(result))
        if chunk:
            result.extend(chunk)
        else:
            time.sleep(.002)
    return bytes(result) if len(result) == size else None


def cmd(data, timeout=2.0, trace_stage=None):
    length = len(data) + 2
    payload = bytes((1, length >> 8, length & 255)) + data
    checksum = sum(payload) & 65535
    u.reset_input_buffer()
    frame = b"\xef\x01\xff\xff\xff\xff" + payload + checksum.to_bytes(2, "big")
    if trace_stage is not None:
        note_wake(trace_stage)
    u.write(frame)
    deadline = time.monotonic() + timeout
    header = uart_read_exact(9, deadline)
    if not header or header[:2] != b"\xef\x01" or header[6] != 7:
        return None
    size = int.from_bytes(header[7:9], "big")
    if not 3 <= size <= 256:
        return None
    tail = uart_read_exact(size, deadline)
    if not tail:
        return None
    if (sum(header[6:]) + sum(tail[:-2])) & 65535 != int.from_bytes(tail[-2:], "big"):
        return None
    return tail[:-2]


def led_off():
    global last_led_off, blue_feedback_until
    reply = cmd(b"\x3c\x04\x00\x00\x00", timeout=.30)
    last_led_off = time.monotonic()
    blue_feedback_until = 0
    return bool(reply and reply[0] == 0)


def show_blue_feedback(record_timing):
    global blue_feedback_until
    # Use the same three-second green flash as the other S3 modes.
    blue_feedback_until = time.monotonic() + 3.0
    try:
        reply = cmd(b"\x3c\x02\x02\x02\x11\x06\x05", timeout=.30)
        if reply and reply[0] == 0:
            blue_feedback_until = time.monotonic() + 3.0
            if record_timing:
                note_wake("green_ack")
    except (OSError, RuntimeError):
        pass


def verify_press(capture_feedback=False):
    started = time.monotonic()
    deadline = started + 2.5
    while time.monotonic() < deadline:
        remaining = deadline - time.monotonic()
        image = cmd(b"\x01", timeout=min(.50, remaining),
                    trace_stage="capture_command" if capture_feedback else None)
        if image and image[0] == 0:
            break
        if not touch.value and (not capture_feedback or time.monotonic() - started >= .12):
            return False
        time.sleep(.025)
    else:
        return False

    if capture_feedback:
        note_wake("image_ready")
    features = cmd(b"\x02\x01")
    if not features or features[0] != 0:
        if capture_feedback:
            note_wake("features_failed")
        led_off()
        return False
    match = cmd(b"\x04\x01\x00\x00\x00\x64",
                trace_stage="search_command" if capture_feedback else None)
    matched = bool(match and match[0] == 0)
    if capture_feedback:
        note_wake("matched" if matched else "no_match")
    print("MATCH" if matched else "NO_MATCH")
    if matched:
        show_blue_feedback(capture_feedback)
    else:
        # Keep the module's normal failure indicator briefly.
        time.sleep(.3)
        led_off()
    return matched


# UART and the touch input are ready. Capture before defining the HID and
# management code or importing modules that are unrelated to the sensor.
woke_match = verify_press(capture_feedback=True) if wake_press else False
if deep_wake and "image_ready" not in wake_events_ns:
    note_wake("capture_missed")

import usb_cdc, json

try:
    from espidf import arm_deep_wake_trace, deep_wake_trace_offset_us
except ImportError:
    arm_deep_wake_trace = None
else:
    if deep_wake:
        offset_us = deep_wake_trace_offset_us()
        if offset_us is not None:
            wake_offset_ns = offset_us * 1000


def log(event):
 print('DS3',event)

class PendingInput:
 def __init__(self):
  self.deadline=None
 def submit(self,now):
  if self.deadline is not None: return False
  self.deadline=now+CONNECT_TIMEOUT
  return True
 def poll(self,now,ready):
  if self.deadline is None: return None
  if now>=self.deadline:
   self.deadline=None; return 'expired'
  if ready:
   self.deadline=None; return 'send'
  return None

class ConnectionGate:
 def __init__(self):
  self.peer=None; self.since=None
 def update(self,now,peer):
  if peer is None:
   self.peer=None; self.since=None; return False
  if peer is not self.peer:
   self.peer=peer; self.since=now
  return now-self.since>=SETTLE_SECONDS

def char(c):
 if 'a'<=c<='z': return (ord(c)-ord('a')+4,False)
 if 'A'<=c<='Z': return (ord(c)-ord('A')+4,True)
 if '1'<=c<='9': return (ord(c)-ord('1')+30,False)
 if c=='0': return (39,False)
 plain=' \t-=[]\\;\'`,./'; codes=(44,43,45,46,47,48,49,51,52,53,54,55,56)
 if c in plain: return (codes[plain.index(c)],False)
 shifted='!@#$%^&*()_+{}|:"~<>?'; shifted_codes=(30,31,32,33,34,35,36,37,38,39,45,46,47,48,49,51,52,53,54,55,56)
 if c in shifted: return (shifted_codes[shifted.index(c)],True)
 raise ValueError('Unsupported character')


KEY_CODES={'BACKSPACE': 42, 'DELETE': 76, 'ESCAPE': 41, 'ENTER': 40, 'TAB': 43, 'SPACE': 44, 'UP_ARROW': 82, 'DOWN_ARROW': 81, 'LEFT_ARROW': 80, 'RIGHT_ARROW': 79, 'HOME': 74, 'END': 77, 'PAGE_UP': 75, 'PAGE_DOWN': 78, 'INSERT': 73, 'F1': 58, 'F2': 59, 'F3': 60, 'F4': 61, 'F5': 62, 'F6': 63, 'F7': 64, 'F8': 65, 'F9': 66, 'F10': 67, 'F11': 68, 'F12': 69}

def macro():
 try:
  if management is not None:
   from zw111_manager import load_macro
   config=json.loads(load_macro().decode())
  else:
   with open('/macro.json','r') as f: config=json.load(f)
  if config.get('version')!=1 or not config.get('enabled',False): return
  steps=config['steps']
  if not isinstance(steps,list) or len(steps)>30: return
  for s in steps:
   delay=float(s.get('delay',0))
   if not 0<=delay<=60: return
   action=s.get('type'); text=s.get('text',''); speed=float(s.get('interval',.1))
   if action not in ('wait','text','enter','key') or not 0<=speed<=2 or len(text)>200: return
   if action=='key' and s.get('key') not in KEY_CODES: return
   if action=='text':
    for c in text: char(c)
  for s in steps:
   time.sleep(float(s.get('delay',0)))
   if s['type']=='text':
    for c in s.get('text',''):
     code,shift=char(c); report(code,shift); time.sleep(float(s.get('interval',.1)))
   elif s['type']=='enter': report(40)
   elif s['type']=='key': report(KEY_CODES[s['key']])
 except Exception:
  log('MACRO_FAILED'); raise


serial_command=b''
def handle_control():
 global serial_command
 port=usb_cdc.console
 if port is None: return
 count=port.in_waiting
 if not count: return
 data=port.read(min(count,64)) or b''
 for c in data:
  if c==10:
   line=serial_command; serial_command=b''
   if line==b'@ZW111:CHECK':
    connected=bool(ble is not None and any(c.paired for c in ble.connections))
    print('__ZW111_BLE_READY__' if connected else '__ZW111_BLE_NOT_PAIRED__')
   elif line==b'@ZW111:VERSION':
    print('__ZW111_VERSION__DS3_WAKE_TRACE')
   elif line==b'@ZW111:WAKE_TIMING':
    print('__ZW111_WAKE_TIMING__',json.dumps(wake_trace()))
   elif line==b'@ZW111:STATUS':
    print('__ZW111_STATE__'+state)
   elif line in (b'@ZW111:KEY29',b'@ZW111:KEY56'):
    try:
     if ble is None or ble_keyboard is None or not any(c.paired for c in ble.connections):
      print('__ZW111_BLE_NOT_PAIRED__'); continue
     key=29 if line.endswith(b'29') else 56
     ble_keyboard.send_report(bytes((0,0,key,0,0,0,0,0)))
     time.sleep(.1); ble_keyboard.send_report(bytes(8))
     print('__ZW111_KEY_OK__')
    except Exception as e: print('__ZW111_KEY_ERROR__',e)
  elif len(serial_command)<80: serial_command+=bytes((c,))
  else: serial_command=b''


# Preserve just this wake's match while BLE starts.
pending = PendingInput()
gate = ConnectionGate()
last_activity = time.monotonic()
wait_release = wake_press
trace_pending = deep_wake and woke_match
if woke_match:
 pending.submit(last_activity)

try:
 from adafruit_ble import BLERadio
 from adafruit_ble.advertising import Advertisement
 from adafruit_ble.advertising.standard import ProvideServicesAdvertisement
 from adafruit_ble.services.standard.hid import HIDService
 hid=HIDService()
 try:
  from zw111_manager import ManagementService

  class DeepManagementService(ManagementService):
   def _execute(self, op, offset, data, now, cmd, key_codes, char):
    if op == 10 and self.authenticated and not data:
     self.deadline = now + 12
     self.download = json.dumps(wake_trace()).encode()
     return 0, len(self.download).to_bytes(2, "big")
    return super()._execute(op, offset, data, now, cmd, key_codes, char)

  management=DeepManagementService()
 except Exception as e:
  print('MANAGEMENT_INIT_FAILED', type(e).__name__, str(e))
 adv=ProvideServicesAdvertisement(hid, management) if management else ProvideServicesAdvertisement(hid); adv.appearance=961
 response=Advertisement(); response.complete_name=_zw111_bluetooth_name()
 ble=BLERadio(); ble.name=_zw111_bluetooth_name()
 ble_keyboard=next(d for d in hid.devices if d.usage_page==1 and d.usage==6)
 ble.start_advertising(adv,response)
 note_wake('advertising')
 log('ADVERTISING')
except Exception:
 log('BLE_INIT_FAILED')
 ble=None

def paired_peer():
 if ble is not None:
  for c in ble.connections:
   if c.connected and c.paired: return c
 return None

def maintain_ble():
 if ble is not None and not ble.connected and not ble.advertising:
  try: ble.start_advertising(adv,response)
  except Exception: log('ADVERTISING_FAILED')

def management_active():
 if management is None or ble is None: return False
 try:
  return management.poll(ble,cmd,KEY_CODES,char)
 except Exception:
  return False

def report(key,shift=False):
 # Lock one transport for the entire macro. Never fall back to USB midway.
 if output_device is ble_keyboard and paired_peer() is None:
  raise RuntimeError('BLE disconnected during macro')
 output_device.send_report(bytes((2 if shift else 0,0,key,0,0,0,0,0)))
 if tracing_hid: note_wake('first_hid_report')
 time.sleep(.035)
 output_device.send_report(bytes(8))

state='IDLE'
log('RUNNING')
while True:
 maintain_ble(); handle_control()
 if management_active():
  if trace_pending: note_wake('macro_cancelled_by_management')
  trace_pending=False
  pending.deadline=None
  wait_release=touch.value
  last_activity=time.monotonic()
  time.sleep(.02); continue
 now=time.monotonic()
 peer=paired_peer()
 if peer is not None: note_wake('ble_paired')
 ready=gate.update(now,peer)
 if pending.deadline is not None:
  state='WAITING_BLE'
  outcome=pending.poll(now,ready)
  if outcome=='send':
   state='SENDING'; output_device=ble_keyboard
   tracing_hid=trace_pending
   trace_pending=False
   try:
    output_device.send_report(bytes(8)); time.sleep(.3)
    if paired_peer() is not peer: raise RuntimeError('BLE connection changed')
    if tracing_hid: note_wake('macro_start')
    macro()
    if tracing_hid: note_wake('macro_finished')
    log('MACRO_FINISHED')
   except Exception:
    if tracing_hid: note_wake('hid_send_failed')
    log('SEND_FAILED_NO_RETRY')
   finally:
    tracing_hid=False
    try: output_device.send_report(bytes(8))
    except Exception: pass
    output_device=None
   last_activity=time.monotonic(); state='IDLE'
  elif outcome=='expired':
   if trace_pending: note_wake('ble_timeout')
   trace_pending=False
   log('CONNECTION_TIMEOUT'); last_activity=now; state='IDLE'
  time.sleep(.05); continue
 if not touch.value:
  wait_release=False
  state='IDLE'
  if now >= blue_feedback_until and now-last_led_off>=2: led_off()
  # Keep USB maintenance accessible; measure true deep sleep on independent power.
  if now-last_activity>=IDLE_SECONDS and not supervisor.runtime.usb_connected:
   state='SLEEPING'; led_off()
   # Leave the sensor touch circuit powered. Sensor power gating needs separate hardware.
   if ble is not None:
    if ble.advertising: ble.stop_advertising()
    for c in ble.connections: c.disconnect()
   touch.deinit()
   wake=alarm.pin.PinAlarm(pin=board.IO4,value=True,pull=False)
   log('SLEEPING')
   if arm_deep_wake_trace is not None: arm_deep_wake_trace()
   alarm.exit_and_deep_sleep_until_alarms(wake,preserve_dios=(_board_led,))
 else:
  last_activity=now
  if not wait_release:
   wait_release=True
   if verify_press(): pending.submit(time.monotonic())
   last_activity=time.monotonic(); state='IDLE'
 time.sleep(.05)
