"""ZW111 PS_ControlBLN success feedback."""
import time

GREEN_FLASH = b"\x3c\x02\x02\x02\x11\x06\x05"
LIGHT_OFF = b"\x3c\x04\x00\x00\x00"
WAIT_LIGHT = b"\x3c\x03\x01\x01\x00"


def flash_green(command):
    # Six half-second cycles at 1:1 duty. The sensor handles the blinking.
    try:
        command(GREEN_FLASH)
    except (OSError, RuntimeError):
        pass
    return time.monotonic() + 3.0
